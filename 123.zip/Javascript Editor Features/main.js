﻿
///add a javascript file.refer to _reference.js since 
//in this file reference is given we can use jquery,modernizer no 
//need to give the reference again
///$(document) write this
///call hello and then right click and goto definition
function hello() {
    ///automatically the outline is added
    var ca = document.getElementById('c1');
    //check without reference first and then add the reference
    //of canvasdemp.aspx
    var ct = c1.getContext('2d');

    //ECMA Script
    Object.defineProperties
   
}
//add a new web form and add a canvas element
//add a reference of canvasdemp.aspx drag and drop in 
//this file 