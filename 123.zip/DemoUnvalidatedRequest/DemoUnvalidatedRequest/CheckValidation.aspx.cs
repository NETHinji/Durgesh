﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DemoUnvalidatedRequest
{
    public partial class CheckValidation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string textValidated = this.Context.Request.Unvalidated.Form[TextBox1.UniqueID];
            string textUnValidated = this.Context.Request.Form[TextBox2.UniqueID];
            //even we have disabled the validation, 
            // when data is accessed from normal Form collection the validation is fired. 

//This again proves the validation is fired only when the data is
            //acessed and when the ValidateRequestMode is set as disabled
            //it is accessed from the UnValidated property.
            /*Note In UnValidated collection and normal in HTTPRequest.
             * When we set the ValidateRequestMode is disabled, the data is accessed 
             * from UnValidated collection else normal request.
             * UnValidated collection don't trigger any validation while
             * other one triggers*/


        }
    }
}